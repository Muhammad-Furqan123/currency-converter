const exchangeRate = 277.58;

for (; ;) { 
    let choice = prompt("Which conversion do you want to perform?\n1: Dollar to PKR\n2: PKR to Dollar\nEnter 1 or 2:");
    if (!choice) break; 

    let amount = prompt("Enter the amount you want to convert:");
    if (!amount) break; 

    // amount = parseFloat(amount);
    if (isNaN(amount)) {
        alert("Please enter a valid number.");
        continue; // If not a number, start the loop again
    }

    if (choice === "1") {
        let convertedAmount = amount * exchangeRate;
        alert(`${amount} Dollars = ${convertedAmount} PKR`);
    } else if (choice === "2") {
        let convertedAmount = amount / exchangeRate;
        alert(`${amount} PKR = ${convertedAmount.toFixed(2)} Dollars`);
    } else {
        alert("Invalid choice. Please enter 1 or 2.");
        continue;
    }

    let anotherConversion = prompt("Do you want to convert another amount? (yes/no):");
    if (anotherConversion.toLowerCase() !== "yes") {
        break; 
    }
}
